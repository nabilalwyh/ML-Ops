import tensorflow as tf

LABEL_KEY = "Exited"

NUMERIC_FEATURE_KEYS = [
    "CreditScore", "Age", "Tenure", "Balance", "NumOfProducts",
    "EstimatedSalary", "Satisfaction Score", "Point Earned"
]

STRING_CATEGORICAL_KEYS = ["Geography", "Gender", "Card Type"]
BINARY_KEYS = ["HasCrCard", "IsActiveMember", "Complain"]

def preprocessing_fn(inputs):
    outputs = {}

    # Numeric features
    for key in NUMERIC_FEATURE_KEYS:
        outputs[transformed_name(key)] = tf.cast(inputs[key], tf.float32)

    # String categorical features
    for key in STRING_CATEGORICAL_KEYS:
        val = inputs[key]
        if isinstance(val, tf.sparse.SparseTensor):
            val = tf.sparse.to_dense(val, default_value='')
        outputs[transformed_name(key)] = tf.strings.lower(val)

    # Binary features
    for key in BINARY_KEYS:
        outputs[transformed_name(key)] = tf.cast(inputs[key], tf.int64)

    # Label
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)

    return outputs
