import tensorflow as tf

LABEL_KEY = "label_ml"
FEATURE_KEY = "text_akhir"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}
    
    # Ambil fitur dan konversi SparseTensor ke dense jika perlu
    text = inputs[FEATURE_KEY]
    if isinstance(text, tf.sparse.SparseTensor):
        text = tf.sparse.to_dense(text, default_value='')
    
    # Ubah teks menjadi lowercase
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(text)
    
    # Label tetap sebagai int64
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    
    return outputs
