import tensorflow as tf

LABEL_KEY = "Exited"

NUMERIC_FEATURE_KEYS = [
    "CreditScore", "Age", "Tenure", "Balance", "NumOfProducts",
    "EstimatedSalary", "Satisfaction Score", "Point Earned"
]

CATEGORICAL_FEATURE_KEYS = ["Geography", "Gender", "HasCrCard", "IsActiveMember", "Complain", "Card Type"]

def transformed_name(key):
    return key + "_xf"

def preprocessing_fn(inputs):
    outputs = {}

    # Transform numeric features
    for key in NUMERIC_FEATURE_KEYS:
        outputs[transformed_name(key)] = tf.cast(inputs[key], tf.float32)
        # Kalau mau normalisasi dengan tft:
        # outputs[transformed_name(key)] = tft.scale_to_z_score(tf.cast(inputs[key], tf.float32))

    # Transform categorical features: lowercase string
    for key in CATEGORICAL_FEATURE_KEYS:
        val = inputs[key]
        if isinstance(val, tf.sparse.SparseTensor):
            val = tf.sparse.to_dense(val, default_value='')
        outputs[transformed_name(key)] = tf.strings.lower(val)

    # Transform label
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)

    return outputs
